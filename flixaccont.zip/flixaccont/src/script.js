// Muestra las últimas películas
document.querySelector("#latestButton").addEventListener("click", function () {
  document.querySelector("#latest").style.display = "block"; // Muestra la sección de últimas películas
  document.querySelector("#offers").style.display = "none"; // Oculta las ofertas si están visibles
  document.querySelector("#purchaseInfo").style.display = "none"; // Oculta la información de compra
  document.querySelector("#gameSection").style.display = "none"; // Oculta la sección de juego
});

// Muestra las ofertas
document.querySelector("#offersButton").addEventListener("click", function () {
  document.querySelector("#offers").style.display = "block"; // Muestra la sección de ofertas
  document.querySelector("#latest").style.display = "none"; // Oculta las últimas películas
  document.querySelector("#purchaseInfo").style.display = "none"; // Oculta la información de compra
  document.querySelector("#gameSection").style.display = "none"; // Oculta la sección de juego
});

// Muestra la información de compra
document.querySelector("#buyButton").addEventListener("click", function () {
  const purchaseInfo = document.querySelector("#purchaseInfo");
  purchaseInfo.style.display =
    purchaseInfo.style.display === "none" ? "block" : "none"; // Alterna la visibilidad
  document.querySelector("#latest").style.display = "none"; // Oculta las últimas películas
  document.querySelector("#offers").style.display = "none"; // Oculta las ofertas
  document.querySelector("#gameSection").style.display = "none"; // Oculta la sección de juego
});

// Maneja el botón de juego
document.querySelector("#gameButton").addEventListener("click", function () {
  document.querySelector("#gameSection").style.display = "block"; // Muestra la sección de juego
  document.querySelector("#latest").style.display = "none"; // Oculta las últimas películas
  document.querySelector("#offers").style.display = "none"; // Oculta las ofertas
  document.querySelector("#purchaseInfo").style.display = "none"; // Oculta la información de compra
  startGame(); // Inicia el juego
});

// Cambiar el tema de la página
document.querySelector("#themeButton").addEventListener("click", function () {
  document.body.style.backgroundColor =
    document.body.style.backgroundColor === "white" ? "#141414" : "white";
  document.body.style.color =
    document.body.style.color === "black" ? "white" : "black";
});

// Juego de preguntas
let score = 0;
const questions = [
  {
    question: "¿Cuál es la capital de Francia?",
    options: ["Berlín", "Madrid", "París", "Lisboa"],
    answer: "París"
  },
  {
    question: "¿Quién escribió 'Cien años de soledad'?",
    options: [
      "Gabriel García Márquez",
      "Jorge Luis Borges",
      "Julio Cortázar",
      "Mario Vargas Llosa"
    ],
    answer: "Gabriel García Márquez"
  },
  {
    question: "¿Cuál es el río más largo del mundo?",
    options: ["Amazonas", "Nilo", "Yangtsé", "Misisipi"],
    answer: "Amazonas"
  },
  {
    question: "¿Qué país tiene la forma de un botín?",
    options: ["Italia", "España", "Francia", "Grecia"],
    answer: "Italia"
  },
  {
    question: "¿Cuál es el planeta más grande del sistema solar?",
    options: ["Tierra", "Marte", "Júpiter", "Saturno"],
    answer: "Júpiter"
  }
];

function startGame() {
  score = 0;
  document.getElementById("score").innerText = score;
  loadQuestion();
}

function loadQuestion() {
  const currentQuestionIndex = Math.floor(Math.random() * questions.length);
  const question = questions[currentQuestionIndex];

  const questionContainer = document.getElementById("questionContainer");
  questionContainer.innerHTML = `<h3>${question.question}</h3>`;

  question.options.forEach((option) => {
    const button = document.createElement("button");
    button.innerText = option;
    button.addEventListener("click", function () {
      if (option === question.answer) {
        score += 20; // Cada respuesta correcta suma 20 puntos
        document.getElementById("score").innerText = score;
        if (score >= 100) {
          alert("¡Felicidades! Has ganado una cuenta de Netflix gratis.");
          resetGame();
        } else {
          loadQuestion(); // Cargar la siguiente pregunta
        }
      } else {
        alert("Respuesta incorrecta. Intenta de nuevo.");
        loadQuestion(); // Cargar la siguiente pregunta
      }
    });
    questionContainer.appendChild(button);
  });
}

function resetGame() {
  score = 0;
  document.getElementById("score").innerText = score;
  const questionContainer = document.getElementById("questionContainer");
  questionContainer.innerHTML = "";
}
